library(tidyverse)

gapminder_2018 <- gapminder_2018 %>%
  mutate(
    year = as.numeric(year),
    co2_per_capita = as.numeric(co2_per_capita)
  )

latest_year <- gapminder_2018 %>%
  filter(!is.na(co2_per_capita)) %>%
  summarise(max_year = max(year)) %>%
  pull(max_year)

latest_year

co2_top40 <- gapminder_2018 %>%
  filter(year == latest_year) %>%
  slice_max(co2_per_capita, n = 40, with_ties = FALSE)

ggplot(co2_top40,
       aes(x = co2_per_capita,
           y = reorder(country, -co2_per_capita),  
           fill = region)) +
  geom_col() +
  labs(
    x = "CO2 emissions per capita (tonnes)",
    y = "Country",
    fill = "Region",
    title = paste("Top 40 countries by CO2 emissions per capita in", latest_year)
  ) +
  theme_minimal()
