library(tidyverse)

gapminder_2018 <- gapminder_2018 %>%
  mutate(
    year = as.numeric(year),
    population = as.numeric(population),
    years_in_school_men   = as.numeric(years_in_school_men),
    years_in_school_women = as.numeric(years_in_school_women)
  )

gapminder_2018 <- gapminder_2018 %>%
  mutate(
    edu_ratio = years_in_school_women / years_in_school_men
  )

gap_edu_1970_2015 <- gapminder_2018 %>%
  filter(year >= 1970, year <= 2015)

edu_income_year <- gap_edu_1970_2015 %>%
  group_by(income_group, year) %>%
  summarise(mean_edu_ratio = mean(edu_ratio, na.rm = TRUE),
            .groups = "drop")

ggplot(edu_income_year,
       aes(x = year, y = mean_edu_ratio,
           color = income_group, group = income_group)) +
  geom_line() +
  geom_point(shape = 15, size = 2) +
  geom_hline(yintercept = 1, linetype = "dashed", color = "grey60") +
  labs(
    x = "Year",
    y = "Ratio (women / men)",
    color = "Income group",
    title = "Female-to-male education years ratio (1970–2015)"
  ) +
  theme_minimal()

