library(tidyverse)

years_keep <- c(1918, 1938, 1958, 1978, 1998, 2018)

gapminder_2018 %>%
  mutate(
    year = as.numeric(year),
    children_per_woman = as.numeric(children_per_woman),
    child_mortality = as.numeric(child_mortality)
  ) %>%
  filter(year %in% years_keep) %>%
  ggplot(aes(
    x = children_per_woman,
    y = child_mortality,
    color = income_group
  )) +
  geom_point(shape = 1, size = 2) +          
  facet_wrap(~ year, ncol = 3) +
  labs(
    x = "Children per woman",
    y = "Child mortality",
    title = "Family planning over time",
    color = "Income group"
  ) +
  theme_minimal()
