library(tidyverse)
library(Hmisc)

gap_edu_1970_2015 <- gapminder_2018 %>%
  mutate(
    year                 = as.numeric(year),
    years_in_school_men   = as.numeric(years_in_school_men),
    years_in_school_women = as.numeric(years_in_school_women),
    edu_ratio = years_in_school_women / years_in_school_men
  ) %>%
  filter(year >= 1970, year <= 2015)

p_edu <- ggplot(
  gap_edu_1970_2015,
  aes(x = year,
      y = edu_ratio,
      color = income_group,
      group = income_group)
) +
  stat_summary(fun = mean, geom = "line") +
  stat_summary(fun = mean, geom = "point",
               shape = 15, size = 2) +
  labs(
    x = "Year",
    y = "Ratio of women’s to men’s years in school",
    color = "Income group",
    title = "Education balance over time by income group"
  ) +
  theme_minimal()

p_edu +
  geom_ribbon(
    aes(
      ymin = ..ymin..,
      ymax = ..ymax..,
      fill = income_group,
      color = NULL
    ),
    stat = "summary",
    fun.data = mean_cl_boot,
    alpha = 0.2
  )
