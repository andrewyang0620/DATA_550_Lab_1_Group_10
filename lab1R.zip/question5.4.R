library(tidyverse)

gapminder_2018 <- gapminder_2018 %>%
  mutate(
    year           = as.numeric(year),
    population     = as.numeric(population),
    co2_per_capita = as.numeric(co2_per_capita),
    co2_total      = co2_per_capita * population
  )

co2_region_year <- gapminder_2018 %>%
  filter(!is.na(co2_total)) %>%
  group_by(year, region) %>%
  summarise(
    total_co2_region = sum(co2_total, na.rm = TRUE),
    .groups = "drop"
  )

ggplot(co2_region_year,
       aes(x = year,
           y = total_co2_region,
           fill = region)) +
  geom_area(position = "stack", alpha = 0.8) +
  labs(
    x = "Year",
    y = "Total CO2 emissions",
    fill = "Region",
    title = "Total CO2 emissions over time by region"
  ) +
  theme_minimal()
