library(tidyverse)
gapminder_2018 <- gapminder_2018 %>%
  mutate(
    year               = as.numeric(year),
    population         = as.numeric(population),
    children_per_woman = as.numeric(children_per_woman),
    life_expectancy    = as.numeric(life_expectancy)
  )

gapminder_2018 %>%
  filter(year == 1962) %>%
  ggplot(
    aes(
      x = children_per_woman,
      y = life_expectancy,
      color = region,
      size = population
    )
  ) +
  geom_point(alpha = 0.6) +                             
  scale_size(range = c(3, 20), name = "Population") +
  labs(
    title = "Life Expectancy vs Children per Woman (1962)",   
    x = "Children per Woman",                                 
    y = "Life Expectancy",
    color = "Region"                                          
  ) +
  theme_bw() +                                                
  theme(
    text = element_text(size = 14),                           
    plot.title = element_text(size = 18, face = "bold")       
  )
