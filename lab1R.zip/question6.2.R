library(tidyverse)

years_use <- c(1979, 1991, 2003, 2015)

gap_subset <- gapminder_2018 %>%
  mutate(
    year   = as.numeric(year),
    income = as.numeric(income)
  ) %>%
  filter(year %in% years_use)
ggplot(gap_subset, aes(x = income)) +
  geom_histogram(bins = 35, fill = "skyblue", color = "white") +
  facet_wrap(~ year, ncol = 4) +
  labs(
    x = "Income (GDP per capita USD)",
    y = "Count of countries",
    title = "Income distribution across selected years"
  ) +
  theme_minimal()
# plot code
#Although this dataset does not use a log scale and we are viewing a histogram rather than a density curve, the overall pattern is still clear. From 1979 to 1991, 2003, and 2015, the income distribution steadily shifts to the right, indicating that fewer countries remain in the very low-income range. This trend suggests a general rise in global income levels and a gradual narrowing of the gap among many middle-income countries. Overall, the pattern aligns reasonably well with Rosling’s original projection.

