library(tidyverse)

colnames_gap <- c(
  "country", "year", "population", "region", "sub_region",
  "income_group", "life_expectancy", "income",
  "children_per_woman", "child_mortality", "pop_density",
  "co2_per_capita", "years_in_school_men",
  "years_in_school_women", "gdp_total"
)

gapminder_2018 <- readr::read_csv(
  "https://raw.githubusercontent.com/UofTCoders/workshops-dc-py/master/data/processed/world-data-gapminder.csv",
  col_names = colnames_gap
)

gapminder_2018 <- gapminder_2018 %>%
  mutate(
    population = as.numeric(population),
    year = as.numeric(year)   
  )

glimpse(gapminder_2018)

gapminder_2018 %>%
  filter(year == 1962) %>%
  ggplot(aes(
    x = children_per_woman,
    y = life_expectancy,
    color = region,
    size = population
  )) +
  geom_point(alpha = 0.7) +
  scale_size(range = c(1, 15)) +
  theme_minimal()

